﻿if (typeof eps === "undefined") {
    eps = {};
}

eps.rootUrl = "../";
eps.emptyGuid = "00000000-0000-0000-0000-000000000000";
eps.verbose = true;
(function(undefined) {
    eps.newGuid = function() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    eps.requireOptions = {
        rootUrl: eps.rootUrl,
        verbose: true,
        loadedScriptUrls: []
    };

    eps.require = function (scriptNames, complete) {
        if (Object.prototype.toString.call(scriptNames) === '[object Array]') {
            var scriptsToLoad = [];
            for (var counter = 0; counter < scriptNames.length; counter++) {
                var url = scriptNames[counter];
                if (url.indexOf("/") !== 0) {
                    // If it doesn't start with a /, we assume the file is relative to the configured root url
                    url = eps.requireOptions.rootUrl + url;
                }
                var scriptToLoad = {
                    Url: url,
                    Done: false
                };
                var loadedCounter = eps.requireOptions.loadedScriptUrls.length;
                while (loadedCounter--) {
                    if (eps.requireOptions.loadedScriptUrls[loadedCounter] === url) {
                        scriptToLoad.Done = true;
                        if (eps.requireOptions.verbose) { console.log("Script " + url + " loaded previously."); }
                        break;
                    }
                }
                scriptsToLoad.push(scriptToLoad);
            }
            var allCached = true;
            for (var counter2 = 0; counter2 < scriptsToLoad.length; counter2++) {
                if (!scriptsToLoad[counter2].Done) {
                    allCached = false;
                    break;
                }
            }
            if (allCached) {
                if (complete)
                    complete();
                return;
            }
            for (var counter3 = 0; counter3 < scriptsToLoad.length; counter3++) {
                var s = document.createElement("script");
                s.scriptsToLoad = scriptsToLoad;
                s.currentScript = scriptsToLoad[counter3];
                s.onload = function () {
                    this.currentScript.Done = true;
                    var allLoaded = true;
                    for (var counter = 0; counter < this.scriptsToLoad.length; counter++) {
                        if (!this.scriptsToLoad[counter].Done) {
                            allLoaded = false;
                            break;
                        }
                    }
                    if (allLoaded && complete)
                        complete();
                    if (eps.requireOptions.verbose) { console.log("Script load success: " + this.currentScript.Url); }
                };
                s.type = "text/javascript";
                s.async = true;
                s.src = s.currentScript.Url;
                document.body.appendChild(s);
                eps.requireOptions.loadedScriptUrls.push(s.currentScript.Url);
            }
        } else {
            eps.require([scriptNames], complete);
        }
    };

    eps.serviceCall = function (options) {
        if (options == undefined || options.length === 0) {
            options = { url: "", type: "", data: "", async: "", callback: "", datatype: "", showstatus: "", statuscontainerid: "" }
        }
        if (options.showstatus == undefined || options.showstatus.length === 0) {
            options.showstatus = true;
        }
        if (options.statuscontainerid == undefined || options.statuscontainerid.length === 0) {
            options.statuscontainerid = "status-container";
        }
        if (options.showstatus) { eps.status("loading", options.statuscontainerid); }

        if (options.callback == undefined || options.url == undefined) {
            var badcall = { Success: false, FailureInformation: "Call must provide callback and url!" };
            options.callback(badcall);
        }
        if (options.type == undefined || options.type.length === 0) {
            options.type = "get";
        }
        if (options.async == undefined || options.async.length === 0) {
            options.async = true;
        }
        if (options.data == undefined || options.data.length === 0) {
            options.data = {};
        }
        if (options.datatype == undefined || options.datatype.length === 0) {
            options.datatype = "";
        }

        var callData = {};
        if (options.data != undefined) {
            for (var k in options.data) callData[k] = options.data[k];
        }

        //this adds the required user info parameter
        var ut = eps.readCookie("BTagUser");
        if (ut != undefined) { callData.UserToken = ut; }
        var at = eps.readCookie("BTagAccess");
        if (at != undefined) { callData.AccessToken = at; }

        if (options.type.toLowerCase() === "post") {
            callData = ko.toJSON(callData);
            if (options.datatype.length === 0) {
                options.datatype = "application/json";
            }
        }
        if (options.type.toLowerCase() === "delete") {
            options.url = options.url + "/" + options.data;
        }
        if (options.type.toLowerCase() === "put") {
            options.url = options.url + "/" + options.datatype;
        }

        $.ajax({
            type: options.type,
            url: eps.rootUrl + options.url,
            data: callData,
            datatype: options.datatype,
            cache: false,
            async: options.async,
            success: function (response) {
                //TODO: remove debug check for expired token
                if (eps.verbose == false) {
                    if (response.TokenExpired == undefined || response.TokenExpired) {
                        window.location.href = eps.rootUrl + "Account/Logon/?info=" + response.FailureInformation;
                        return;
                    }
                }
                options.callback(response);
                if (options.showstatus) { eps.status("ready", options.statuscontainerid); }
            },
            error: function (xhr2, status2, error2) {
                var message = status2 + " / " + error2;
                if (xhr2 != undefined && xhr2.responseText != undefined) {
                    var s = xhr2.responseText.indexOf("<title>");
                    var e = xhr2.responseText.indexOf("</title>");
                    if (s > 0 && e > s) {
                        var l = e - s;
                        message = xhr2.responseText.substr(s + 7, l - 7);
                    }
                }
                var response = { Status: 99, Success: false, FailureInformation: "Error :" + message };
                options.callback(response);
                if (options.showstatus) { eps.status("ready", options.statuscontainerid); }
            }
        });
    }

    eps.status = function(status, elementid) {
        if (status == undefined || status.length === 0) {
            status = "loading";
        }
        if (elementid == undefined || elementid.length === 0) {
            elementid = "status-container";
        }
        if (status === "loading") {
            //$(element).fadeIn();
            $("#" + elementid).show();
        } else {
            //$(element).fadeOut();
            $("#" + elementid).hide();
        }
    }

    eps.notificationOptions = {
        cntr: 0,
        delayInfinite: 0,
        delayShort: 2000,
        delayNormal: 5000,
        delayLong: 8000
    }
    eps.notification = function(notification, level, duration) {
        if (level != undefined) {
            if (level.toLowerCase() === "success") {
                level = "success";
            } else if (level.toLowerCase() === "info") {
                level = "info";
            } else if (level.toLowerCase() === "warning") {
                level = "warning";
            } else {
                level = "danger";
            }
        } else {
            level = "danger";
        }
        var html = "<div id='notification" + eps.notificationOptions.cntr + "' style='display:none' class='alert alert-" + level + "  alert-dismissible'>" +
            "<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>" +
            notification + "</div>";
        var delay = eps.notificationOptions.delayNormal;
        if (duration != undefined) {
            if (duration === false || duration === 0) {
                delay = 0;
            } else if(duration.toString().toLowerCase() === "short"){
                delay = eps.notificationOptions.delayShort;
            } else if (duration.toString().toLowerCase() === "long") {
                delay = eps.notificationOptions.delayLong;
            }
        } 

        $("#notification-container").append(html);
        $("#notification" + eps.notificationOptions.cntr).slideDown("slow");
        if (delay > 0) {
            $("#notification" + eps.notificationOptions.cntr).delay(delay).slideUp("slow");
        }
        eps.notificationOptions.cntr = eps.notificationOptions.cntr + 1;
    };

    eps.messageBox = function (options) {
        if (options == undefined || options.length === 0) {
            options = { title: "", body: "", buttons: [], callback: null, getInput : false}
        }
        if (options.title == undefined || options.title.length === 0) {
            options.title = "TreadStat Message";
        }
        if (options.body == undefined || options.body.length === 0) {
            options.body = "Are your sure?";
        }
        if (options.buttons == undefined || options.buttons.length === 0) {
            options.buttons = ["Yes", "No"];
        }
        //for (var b = 0; b < options.buttons.length; b++) {
        //    options.buttons[b] = eps.stripCharacters(options.buttons[b]);
        //}
        if (options.getInput == undefined || options.getInput.length === 0) {
            options.getInput = false;
        }

        $("#message-buttons").empty();
        for (var i = 0; i < options.buttons.length; i++) {
            var html = "<button id='message-button-" + eps.stripCharacters(options.buttons[i]) + "'>" + options.buttons[i] + "</button>";
            $("#message-buttons").append(html);
        }
        switch (options.buttons.length) {
        case 1:
            $("#message-button-" + eps.stripCharacters(options.buttons[0])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[0], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[0]);
                    }
                }
            });
        case 3:
            $("#message-button-" + eps.stripCharacters(options.buttons[0])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[0], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[0]);
                    }
                }
            });
            $("#message-button-" + eps.stripCharacters(options.buttons[1])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[1], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[1]);
                    }
                }
            });
            $("#message-button-" + eps.stripCharacters(options.buttons[2])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[2], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[2]);
                    }
                }
            });
        default:
            $("#message-button-" + eps.stripCharacters(options.buttons[0])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[0], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[0]);
                    }
                }
            });
            $("#message-button-" + eps.stripCharacters(options.buttons[1])).click(function () {
                $("#message-container").slideUp(400, function() {
                    $("#message-box").hide();
                });
                if (options.callback) {
                    if (options.getInput) {
                        options.callback(options.buttons[1], $("#message-input").val());
                    } else {
                        options.callback(options.buttons[1]);
                    }
                }
            });
        }

        $("#message-title").html(options.title);
        $("#message-body").html(options.body);
        if (options.getInput) { $("#message-body").append("<input type='text' id='message-input' class='form-control' />"); }
        $("#message-box").show();
        $("#message-container").hide().slideDown();
    };

    eps.readCookie = function (name, key) {
        if (name == undefined || name.length === 0) {return "";}
        var allcookies = document.cookie;
        var allCookiesArray = allcookies.split(';');
        // Now take key value pair out of this array
        for (var i = 0; i < allCookiesArray.length; i++) {
            //console.log("Current cookie:" + allCookiesArray[i]);
            var cookieName = allCookiesArray[i].substr(0, allCookiesArray[i].indexOf("="));
            if (key == undefined || key.length === 0) {
                if (cookieName.toLowerCase().indexOf(name.toLowerCase()) > -1) {
                    //console.log("found a match!");
                    return allCookiesArray[i].substr(allCookiesArray[i].indexOf("=") + 1);
                }
            } else {
                var keyArray = allCookiesArray[i].substr(allCookiesArray[i].indexOf("=") + 1).split("&");
                //console.log("Cookie Name:" + cookieName);
                for (var k = 0; k < keyArray.length; k++) {
                    //console.log("Current Key:" + keyArray[k]);
                    var valueArray = keyArray[k].split("=");
                    if (valueArray.length > 1) {
                        //console.log("looking for key:" + key.toLowerCase());
                        //console.log("looking at:" + valueArray[0].toLowerCase());
                        if (valueArray[0].toLowerCase() == key.toLowerCase()) {
                            return valueArray[1];
                        }
                    }
                    //console.log("Current Key:" + valueArray[0]);
                    //console.log("Current Value:" + valueArray[1]);
                }
            }
        }
        return "";
    }

    eps.writeCookie = function (cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires + ";path=/";
    }

    //reads JSON based cookie created by writeJsonCookie or Security Helper EncryptObjectJson (if InTestMode = true)
    //name = name of cookie to parse
    //key (optional) looks for specified key inside the JSON value of the cookie. If not found returns empty string
    //               If key is not supplied then the entire cookie value is returned
    //returnAsString controls return type. Default = true and will return string. If set to false will return JSON object
    //example: eps.readJsonCookie("Customer","FirstName")
    //returns: "Jeff"
    //example: eps.readJsonCookie("Customer","FirstName", false)
    //returns: {"FirstName":"Jeff","LastName":"Etter"}
    //example: eps.readJsonCookie("Customer")
    //returns: "{"FirstName":"Jeff","LastName":"Etter"}"
    //example: eps.readJsonCookie("Customer","",false)
    //returns: {"FirstName":"Jeff","LastName":"Etter"}
    eps.readJsonCookie = function (name, key, returnAsString) {
        if (name == undefined || name.length === 0) {return "";}
        if (returnAsString == undefined || returnAsString.length === 0) { returnAsString = true; }
        var allcookies = document.cookie;
        var allCookiesArray = allcookies.split(';');
        // Now take key value pair out of this array
        for (var i = 0; i < allCookiesArray.length; i++) {
            var cookieName = allCookiesArray[i].substr(0, allCookiesArray[i].indexOf("="));
            //just grab the entire cookie value
            if (key == undefined || key.length === 0) {
                if (cookieName.toLowerCase().indexOf(name.toLowerCase()) > -1) {
                    var cookieValue =  allCookiesArray[i].substr(allCookiesArray[i].indexOf("=") + 1);
                    if (returnAsString) {
                        return cookieValue.substring(0, cookieValue.indexOf("::"));
                    } else {
                        return JSON.parse(cookieValue.substring(0, cookieValue.indexOf("::")));
                    }
                }
            } else {
                //look for a specific cookie value key
                if (cookieName.toLowerCase().indexOf(name.toLowerCase()) > -1) {
                    var keyArray = allCookiesArray[i].substr(allCookiesArray[i].indexOf("=") + 1).split("|");
                    for (var k = 0; k < keyArray.length; k++) {
                        if (keyArray[k].indexOf("ObjectValue") > -1) {
                            //console.log("Current Key:" + keyArray[k]);
                            var valueArray = keyArray[k].split("::");
                            for (var v = 0; v < valueArray.length; v++) {
                                //console.log("Looking at Value segment:" + valueArray[v]);
                                if (valueArray[v].indexOf("ObjectValue") === -1) {
                                    var valueJson = JSON.parse(valueArray[v]);
                                    if (returnAsString) {
                                        return valueJson[key] ? valueJson[key] : "";
                                    } else {
                                        return valueJson[key] ? valueJson : {};
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (returnAsString) {
            return "";
        } else {
            return {};
        }
    }

    //Removes specified key from JSON payload of cookie with supplied name (IS case sensitive)
    //Cookie must be in compatible format generated by the writeJsonCookie method.
    //name = name of cookie to parse
    //keyNames = array of JSON keys to remove
    //example: eps.removeKeyJsonCookie("Customer",["FirstName"])
    //result: cookie with following value Customer={"LastName","Etter"}::ObjectValue|Project.Namespace.Customer::ObjectName
    eps.removeKeysJsonCookie = function (name, keyNames) {
        if (name !== undefined || name.length !== 0) {
            var allcookies = document.cookie;
            var allCookiesArray = allcookies.split(';');
            // Now take key value pair out of this array
            for (var i = 0; i < allCookiesArray.length; i++) {
                var cookieName = allCookiesArray[i].substr(0, allCookiesArray[i].indexOf("="));
                //look for a specific cookie value key
                if (cookieName.toLowerCase().indexOf(name.toLowerCase()) > -1) {
                    var keyArray = allCookiesArray[i].substr(allCookiesArray[i].indexOf("=") + 1).split("|");
                    var valueJson = "";
                    var valueObjectName = "";
                    for (var k = 0; k < keyArray.length; k++) {
                        if (keyArray[k].indexOf("ObjectValue") > -1) {
                            //console.log("Current Key:" + keyArray[k]);
                            var valueArray = keyArray[k].split("::");
                            for (var v = 0; v < valueArray.length; v++) {
                                //console.log("Looking at Value segment:" + valueArray[v]);
                                if (valueArray[v].indexOf("ObjectValue") === -1) {
                                    valueJson = JSON.parse(valueArray[v]);
                                    for (var n = 0; n < keyNames.length; n++) {
                                        delete valueJson[keyNames[n]];
                                    }
                                }
                            }
                        }
                        if (keyArray[k].indexOf("ObjectName") > -1) {
                            var nameArray = keyArray[k].split("::");
                            for (var o = 0; o < nameArray.length; o++) {
                                //console.log("Looking at Value segment:" + valueArray[v]);
                                if (nameArray[o].indexOf("ObjectName") === -1) {
                                    valueObjectName = nameArray[o];
                                }
                            }
                        }
                        eps.writeJsonCookie(name, valueJson, valueObjectName);
                    }
                }
            }
        }
    }

    //Adds or Updates a cookie in a format compatible with cookieReadJson and SecurityHelper DecryptObjectJson (if InTestMode = true)
    //cookieName = name of cookie to create (NOTE: Name IS case sensitive)
    //object = JavaScript object to insert into the value of the cookie
    //objectName (optional) = fully qualified class name of object contained in JSON payload. 
    //                        Required for the SecurityHelper DecryptObjectJson to create object
    //expireDays (option) = number of days before cookie expiration (can be negative)
    //example: eps.cookieWriteJson("Customer",{FirstName:"Jeff",LastName:"Etter"}, "Project.Namespace.Customer")
    //result: cookie with following value Customer={"FirstName":"Jeff","LastName","Etter"}::ObjectValue|Project.Namespace.Customer::ObjectName
    eps.writeJsonCookie = function (cookieName, object, objectName, expireDays) {
        if (cookieName == undefined || object == undefined) { return; }
        var cvalue = "";
        var expires = "";
        cvalue = JSON.stringify(object) + "::ObjectValue";
        if (objectName != undefined) {
            cvalue = cvalue + "|" + objectName + "::ObjectName";
        }
        if (expireDays !== undefined) {
            var d = new Date();
            d.setTime(d.getTime() + (expireDays * 24 * 60 * 60 * 1000));
            expires = "expires=" + d.toUTCString();
        }
        document.cookie = cookieName + "=" + cvalue + "; " + expires + ";path=/";
    }

    eps.stripCharacters = function(value) {
        return value.replace(/\W/g, '');
    }

    eps.log = function(message) {
        if (eps.verbose) {
            console.log(message);
        }
    }

})();
