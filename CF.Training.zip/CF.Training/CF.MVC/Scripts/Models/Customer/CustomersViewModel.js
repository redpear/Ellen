﻿var CustomerListItemViewModel = function (data) {
    var self = this;
    self.Id = ko.observable(data.Id);
    self.FirstName = ko.observable(data.FirstName);
    self.LastName = ko.observable(data.LastName);
    self.Address = ko.observable(data.Address);
    self.Phone = ko.observable(data.Phone);
    self.CreditLimitId = ko.observable(data.CreditLimitId);
    self.InActive = ko.observable(data.InActive);

    self.DisplayName = ko.computed(function () {
        return self.FirstName() + " " + self.LastName();
    });
    self.Selected = ko.observable(false);
    //this property will be used later to enhance the look
    self.Css = ko.computed(function () {
        var css = "card";
        if (self.Selected()) { css = css + " selected"; }
        if (self.InActive()) { css = css + " inActive"; }
        return css;
    });
}
var CustomersViewModel = function () {
    var self = this;
    self.items = ko.observableArray([]);
    self.SelectedItem = ko.observable(null);
    self.SelectItem = function (item) {
        if (self.SelectedItem() != null && item.Id() === self.SelectedItem().Id)
        { return; }
        self.SelectedItem(item);
        self.SelectedItem(item.Id());
        self.SelectedItem(item.FirstName());
        item.Selected(true);

        eps.require(["Scripts/Models/Customer/CustomerViewModel.js"],
         function () {
             MainVM.CustomerVM(new CustomerViewModel());
             MainVM.CustomerVM().Load(item.Id());
         });

    }



    // AB added
    self.AddNew = function () {

        //self.items(new Customer({}));
        //if (items.Id != eps.emptyGuid) {

        //    //self.Customers.push(new Customer({Id: self.Id, FirstName: self.FirstName, LastName: self.LastName, Address: self.Address, Phone: self.Phone, CreditLimitId: self.CreditLimitId, Inactive: false }));

        //    self.Customer(new CustomerItemViewModel({
        //        Id: eps.emptyGuid,
        //        FirstName: self.FirstName,
        //        LastName: self.LastName,
        //        Address: self.Address,
        //        Phone: self.Phone,
        //        CreditLimitId: self.CreditLimitId,
        //        Inactive: false
        //    }));
        //    return;
        //}
        //  }

        //3self.Customers.push(new Customer({Id:123,Name:"Jack"});
    };

    self.Load = function () {
        //when calling the service do NOT use the eps.status, 
        //instead pass in the element Id used here to the eps.servicecall
        eps.status("loading", "status-container-customers");
        //simulate service delay....
        setTimeout(function () {
            var response = fakeData;
            self.items($.map(response.Customers, function (item) {
                return new CustomerListItemViewModel(item);
            }));
            eps.status("ready", "status-container-customers");
        }, 2000);

    };
};
