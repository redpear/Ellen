﻿var CustomerItemViewModel = function (data) {
    var self = this;
    self.Id = ko.observable(data.Id);
    self.FirstName = ko.observable(data.FirstName);
    self.LastName = ko.observable(data.LastName);
    self.Address = ko.observable(data.Address);
    self.Phone = ko.observable(data.Phone);
    self.CreditLimitId = ko.observable(data.CreditLimitId);
    self.InActive = ko.observable(data.InActive);

    self.Css = ko.computed(function () {
        return self.InActive() ? " inActive" : "";
    });
};


var CustomerViewModel = function () {
    var self = this;

    self.Customer = ko.observable(null);
    self.Delete = function () {
        //eps.log("feature not yet implemented", "warning");

        //if(self.Id != null)
        //{

        //}
    }
    self.Cancel = function () {
        if (MainVM != undefined) {
            MainVM.CustomerVM(null);
        }
    }

    self.CanDelete = ko.computed(function () {
        if (self.Customer() === null) return false;
        return self.Customer().Id() !== eps.emptyGuid;
    });

    self.Load = function (customerId) {
        if (customerId === eps.emptyGuid) {
            //load default values
            self.Customer(new CustomerItemViewModel({
                Id: eps.emptyGuid,
                FirstName: "",
                LastName: "",
                Address: "",
                Phone: "",
                CreditLimitId: null,
                Inactive: false
            }));
            return;
        }
        //when calling the service do NOT use the eps.status, 
        //instead pass in the element Id used here to the eps.servicecall
        eps.status("loading", "status-container-customer-edit");
        //simulate service delay....
        setTimeout(function () {

            //we have fake data to look up some values...
            for (var i = 0; i < fakeData.Customers.length; i++) {
                if (fakeData.Customers[i].Id == customerId) {
                    var response = {
                        Success: true,
                        Customer: {
                            Id: fakeData.Customers[i].Id,
                            FirstName: fakeData.Customers[i].FirstName,
                            LastName: fakeData.Customers[i].LastName,
                            Address: fakeData.Customers[i].Address,
                            Phone: fakeData.Customers[i].Phone,
                            CreditLimitId: fakeData.Customers[i].CreditLimitId,
                            InActive: fakeData.Customers[i].InActive
                        }
                    }
                }
            }

            self.Customer(new CustomerItemViewModel(response.Customer));
            eps.status("ready", "status-container-customer-edit");
        }, 500);
    };


    self.Save = function () {
        //for our fake data, generate an ID when saving
        if (self.Customer().Id() === eps.emptyGuid) {
            self.Customer().Id(eps.newGuid());
        }
        if (MainVM !== null && MainVM.CustomersVM() !== null) {
            MainVM.CustomersVM().UpdateList(self.Customer());
            MainVM.CustomerVM().UpdateList(self.Customer());
        }

        self.CanDelete = ko.computed(function () {
            if (self.Customer() === null) return false;
            return self.Customer().Id() !== eps.emptyGuid;
        });

        self.Load = function (customerId) {
            if (customerId === eps.emptyGuid) {
                //load default values
                self.Customer(new CustomerItemViewModel({
                    Id: eps.emptyGuid,
                    FirstName: "",
                    LastName: "",
                    Address: "",
                    Phone: "",
                    CreditLimitId: null,
                    Inactive: false
                }));
                return;
            }
        //when calling the service do NOT use the eps.status, 
        //instead pass in the element Id used here to the eps.servicecall
        //eps.status("loading", "status-container-customer-edit");
        ////simulate service delay....
        setTimeout(function () {

            //we have fake data to look up some values...
            for (var i = 0; i < fakeData.Customers.length; i++) {
                if (fakeData.Customers[i].Id == customerId) {
                    var response = {
                        Success: true,
                        Customer: {
                            Id: fakeData.Customers[i].Id,
                            FirstName: fakeData.Customers[i].FirstName,
                            LastName: fakeData.Customers[i].LastName,
                            Address: fakeData.Customers[i].Address,
                            Phone: fakeData.Customers[i].Phone,
                            CreditLimitId: fakeData.Customers[i].CreditLimitId,
                            InActive: fakeData.Customers[i].InActive
                        }
                    }
                }
            }

            self.Customer(new CustomerItemViewModel(response.Customer));
            eps.status("ready", "status-container-customer-edit");
        }, 500);
        };
    };
};
