﻿var MainCustomerViewModel = function () {
    var self = this;
    self.CustomerVM = ko.observable(null);
    self.CustomersVM = ko.observable(null);
    self.Load = function () {
        eps.require(["Scripts/Models/Customer/CustomersViewModel.js"],
            function () {
                MainVM.CustomersVM(new CustomersViewModel());
                MainVM.CustomersVM().Load();
            });
    };
};

var fakeData = {
    Success: true,
    Customers: [
    {
        Id: 123, FirstName: "Jack", LastName: "Jones",
        Address: "123 Street", Phone: "888-888-8888", CreditLimitId: 123,
        InActive: false
    },
    {
        Id: 456, FirstName: "Jack", LastName: "Robinson",
        Address: "234 Street", Phone: "666-666-6666", CreditLimitId: 234,
        InActive: true
    },
    {
        Id: 567, FirstName: "Ted", LastName: "Smith",
        Address: "345 Street", Phone: "555-555-5555", CreditLimitId: 345,
        InActive: true
    },
    {
        Id: 678, FirstName: "Clint", LastName: "Eastwood",
        Address: "456 Street", Phone: "777-777-7777", CreditLimitId: 456,
        InActive: false
    }
    ]
}


