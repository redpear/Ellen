using CODE.Framework.Wpf.Mvvm;
using Project.Client.Wpf1.Models.Customer;
using System;

namespace Project.Client.Wpf1.Controllers
{
    public class CustomerController : Controller
    {
        public ActionResult List()
        {
            var model = new CustomerListViewModel();
            return View(model);
        }

        public ActionResult Add()
        {
            var model = new CustomerEditViewModel();
            return View("Edit", model);
        }

        public ActionResult Edit(Guid id)
        {
            var model = new CustomerEditViewModel(id);
            return View(model);
        }
    }
}
