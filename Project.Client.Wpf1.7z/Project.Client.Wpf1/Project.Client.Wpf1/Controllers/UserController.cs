using CODE.Framework.Wpf.Mvvm;
using Project.Client.Wpf1.Models.User;

namespace Project.Client.Wpf1.Controllers
{
    public class UserController : Controller
    {
        public ActionResult Login()
        {
            return ViewModal(new LoginViewModel(), ViewLevel.Popup);
        }
    }
}
