using CODE.Framework.Wpf.Mvvm;
using System;

namespace Project.Client.Wpf1.Models.Customer
{
    public class CustomerEditViewModel : ViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public DateTime CustomerSince { get; set; }

        public CustomerEditViewModel()
        {
            LoadData();

            // TODO: Populate actions and default property values here
           // Actions.Add(new ViewAction("Action", execute: (a, o) => { /* Do something here */ }));
           // Actions.Add(new CloseCurrentViewAction(this, beginGroup: true));
        }

        public CustomerEditViewModel(Guid id)
        {
            LoadData(id);

            // TODO: Populate actions and default property values here
           // Actions.Add(new ViewAction("Example", execute: (a, o) => { /* Do something here */ }));
           // Actions.Add(new CloseCurrentViewAction(this, beginGroup: true));
        }

        public void LoadData()
        {
            // TODO: this is where the service call would be made to get the data
            Id = new Guid();
            Name = "Angie Add";
            Address = "123 NW Park Street";
            Phone = "674-345-2378";
            CustomerSince = new DateTime(20016/04/16);
        }
    

        public void LoadData(Guid id)
        {
            // TODO: this is where the service call would be made to get the data
            Id = id;
            Name = "Mike P";
            Address = "123 SE Samson Street";
            Phone = "674-345-2378";
            CustomerSince = new DateTime(20016/01/15);
        }
    }
}
