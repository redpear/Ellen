using CODE.Framework.Wpf.Mvvm;
using System;
using System.Collections.ObjectModel;

namespace Project.Client.Wpf1.Models.Customer
{
    public class CustomerListViewModel : ViewModel
    {
        public IViewAction Edit { get; set; }
        public ObservableCollection<CustomerListDataViewModel> Customers { get; set; }
        public CustomerListDataViewModel SelectedCustomer { get; set; }

        public CustomerListViewModel()
        {
            Customers = new ObservableCollection<CustomerListDataViewModel>();

            LoadData();


            Edit = new ViewAction("Edit", execute: (a, p) => Controller.Action("Customer", "Edit", new { Id = SelectedCustomer.Id }));

             Actions.Add(new ViewAction("Add", execute: (a, o) => Controller.Action("Customer", "Add")));
            // Actions.Add(new CloseCurrentViewAction(this, beginGroup: true));
        }

        public void LoadData()
        {
            //TODO: comment to call a service 
            //fake the call by filling in some data using the Customers.Add() method. 
            //Add at least 3 fake customers.
            Customers.Add(new CustomerListDataViewModel
                        {
                            Id = Guid.Empty,
                            Name = "Angie Burk",
                            Address = "123 NW Park",
                            Phone = "546-901-3435"

                        });

            Customers.Add(new CustomerListDataViewModel
                        {
                            Id = Guid.Empty,
                            Name = "Mike P",
                            Address = "552 SE Samson Street",
                            Phone = "546-901-2245"

                        });

            Customers.Add(new CustomerListDataViewModel
                        {
                            Id = Guid.Empty,
                            Name = "Sally Sorenson",
                            Address = "432 SW Winter Court",
                            Phone = "546-901-6734"

                        });
        }
    }

    public class CustomerListDataViewModel : ViewModel 
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }

        public CustomerListDataViewModel()
        {
            Id = Guid.Empty;
            Name = string.Empty;
            Address = string.Empty;
            Phone = string.Empty;
        }
    
    
    }
}
