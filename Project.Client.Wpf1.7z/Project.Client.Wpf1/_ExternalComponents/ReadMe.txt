This project is a dummy project. It serves the purpose of providing folders to store external components, such as the CODE Framework DLLs, without having to use the GAC or a shared folder outside the solution.

This project does not have to be included in the build process. Feel free to set this project to not build in the build configuration manager.